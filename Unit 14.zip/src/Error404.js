

function Error404() {
  return (
    <div>
      <p>Very sorry, this page not exist</p>


    </div>
  );
}

export default Error404;
