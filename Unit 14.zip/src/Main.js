

function Main() {
  return (
    <div>
      <p>Содержимое главной страницы</p>
    </div>
  );
}

export default Main;
