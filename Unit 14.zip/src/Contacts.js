

function Contacts() {
  return (
    <div>
      <p>Contacts</p>


    </div>
  );
}

export default Contacts;
