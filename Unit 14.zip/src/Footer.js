

function Footer() {
  return (
    <div>
      <h3>Это подвал</h3>


    </div>
  );
}

export default Footer;
